import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  LayoutDashboard, Building2, House, Box, FileText, Monitor, Zap, Droplets,
  Wind, ClipboardCheck, AlertTriangle, ClipboardList, Wrench, BarChart3,
  Folder, Search, Bell, ChevronDown, ChevronLeft, Plus, Printer, CalendarDays,
  ArrowUpRight, ArrowDownRight, Clock3, CheckCircle2, CircleAlert, Menu,
  Settings, Users, Package, Wallet, X, Filter, MoreHorizontal, HardHat
} from 'lucide-react';
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
  BarChart, Bar, PieChart, Pie, Cell, Legend
} from 'recharts';
import './styles.css';

const menuGroups = [
  { label: 'ภาพรวม', items: [{ name: 'Dashboard', icon: LayoutDashboard }] },
  { label: 'โครงการ', items: [{ name: 'โครงการทั้งหมด', icon: Building2 }, { name: 'แบบบ้าน', icon: House }] },
  { label: 'ออกแบบ', items: [{ name: 'Structure 3D', icon: Box }, { name: 'Blueprint', icon: FileText }, { name: 'CAD Viewer', icon: Monitor }] },
  { label: 'งานระบบ & อุปกรณ์', items: [{ name: 'ไฟฟ้า', icon: Zap }, { name: 'ประปา & สุขภัณฑ์', icon: Droplets }, { name: 'ปรับอากาศ', icon: Wind }, { name: 'อุปกรณ์อาคาร', icon: Settings }] },
  { label: 'งานปฏิบัติการ', items: [{ name: 'การตรวจสอบ', icon: ClipboardCheck }, { name: 'แจ้งซ่อม/ปัญหา', icon: AlertTriangle, count: 20 }, { name: 'ใบสั่งงาน', icon: ClipboardList }, { name: 'บำรุงรักษา', icon: Wrench }] },
  { label: 'ข้อมูล', items: [{ name: 'รายงาน', icon: BarChart3 }, { name: 'เอกสาร', icon: Folder }] }
];

const projects = [
  { id: 'PRJ-2026-001', name: 'บ้านพักอาศัย 2 ชั้น – บางนา', client: 'คุณธนากร', progress: 78, status: 'กำลังก่อสร้าง', value: '฿12.8M', date: '30 ธ.ค. 2569' },
  { id: 'PRJ-2026-002', name: 'โครงการบ้านเดี่ยว Type A', client: 'บริษัท เอสเตท จำกัด', progress: 52, status: 'กำลังก่อสร้าง', value: '฿8.5M', date: '15 ม.ค. 2570' },
  { id: 'PRJ-2026-003', name: 'อาคารสำนักงาน 4 ชั้น', client: 'คุณพิมพ์ชนก', progress: 100, status: 'ส่งมอบแล้ว', value: '฿21.4M', date: '10 พ.ย. 2569' },
  { id: 'PRJ-2026-004', name: 'รีโนเวทบ้านพักอาศัย', client: 'คุณกิตติ', progress: 24, status: 'วางแผน', value: '฿3.2M', date: '28 ก.พ. 2570' },
  { id: 'PRJ-2026-005', name: 'บ้านพักตากอากาศ หัวหิน', client: 'คุณศิริพร', progress: 61, status: 'กำลังก่อสร้าง', value: '฿6.7M', date: '05 ม.ค. 2570' }
];

const trend = [
  { month: 'ธ.ค. 68', contract: 5, delivered: 1 }, { month: 'ม.ค. 69', contract: 7, delivered: 2 },
  { month: 'ก.พ. 69', contract: 6, delivered: 2 }, { month: 'มี.ค. 69', contract: 9, delivered: 3 },
  { month: 'เม.ย. 69', contract: 8, delivered: 2 }, { month: 'พ.ค. 69', contract: 13, delivered: 4 },
  { month: 'มิ.ย. 69', contract: 11, delivered: 3 }, { month: 'ก.ค. 69', contract: 17, delivered: 5 },
  { month: 'ส.ค. 69', contract: 14, delivered: 4 }, { month: 'ก.ย. 69', contract: 19, delivered: 6 },
  { month: 'ต.ค. 69', contract: 16, delivered: 5 }, { month: 'พ.ย. 69', contract: 21, delivered: 7 }
];
const statusData = [
  { name: 'กำลังก่อสร้าง', value: 10, color: '#e99b18' },
  { name: 'ส่งมอบแล้ว', value: 26, color: '#16b889' },
  { name: 'วางแผน', value: 3, color: '#8b5cf6' },
  { name: 'รอตรวจรับ', value: 1, color: '#2d91c1' }
];
const repairs = [
  { id: 'MR-26041', title: 'ระบบไฟฟ้าชั้น 2 ไฟตก', project: 'บ้านพักอาศัย 2 ชั้น – บางนา', priority: 'เร่งด่วน', age: 'วันนี้' },
  { id: 'MR-26038', title: 'น้ำรั่วบริเวณห้องน้ำ', project: 'โครงการบ้านเดี่ยว Type A', priority: 'ปกติ', age: '1 วันที่แล้ว' },
  { id: 'MR-26035', title: 'เครื่องปรับอากาศไม่เย็น', project: 'บ้านพักตากอากาศ หัวหิน', priority: 'ปกติ', age: '2 วันที่แล้ว' }
];

function App() {
  const [active, setActive] = useState('Dashboard');
  const [query, setQuery] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [range, setRange] = useState('12 เดือน');
  const [toast, setToast] = useState('');
  const filteredProjects = useMemo(() => projects.filter(p => `${p.name} ${p.id} ${p.client}`.toLowerCase().includes(query.toLowerCase())), [query]);

  const notify = (msg) => { setToast(msg); window.setTimeout(() => setToast(''), 2600); };
  const pageTitle = active === 'Dashboard' ? 'Dashboard' : active;
  const isDashboard = active === 'Dashboard';

  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
      <div className="brand">
        <div className="brand-mark"><House size={22} strokeWidth={2.5}/></div>
        <div className="brand-copy"><strong>โฮมกราฟท์ บิลเดอร์</strong><span>BUILD · INSPECT · CARE</span></div>
        <button className="collapse-btn" onClick={() => setMobileOpen(false)} aria-label="ปิดเมนู"><ChevronLeft size={17}/></button>
      </div>
      <nav className="side-nav">
        {menuGroups.map(group => <section className="nav-group" key={group.label}>
          <div className="nav-label">{group.label}</div>
          {group.items.map(item => <button key={item.name} onClick={() => { setActive(item.name === 'ภาพรวม' ? 'Dashboard' : item.name); setMobileOpen(false); }} className={`nav-item ${active === item.name || (active === 'Dashboard' && item.name === 'Dashboard') ? 'selected' : ''}`}>
            <item.icon size={17}/><span>{item.name}</span>{item.count && <em>{item.count}</em>}
          </button>)}
        </section>)}
      </nav>
      <div className="support-card"><div className="support-icon"><HardHat size={17}/></div><div><small>สายด่วนบริการ</small><strong>095-168-8800</strong></div></div>
      <div className="sidebar-user"><div className="avatar">ก</div><div><strong>ผู้ดูแลระบบ</strong><small>Administrator</small></div><span className="online-dot"/></div>
    </aside>

    <main className="main-area">
      <header className="topbar">
        <button className="mobile-menu" onClick={() => setMobileOpen(!mobileOpen)}><Menu size={20}/></button>
        <div className="breadcrumb"><span>ภาพรวม</span><strong>{pageTitle}</strong></div>
        <div className="top-actions">
          <div className="search-box"><Search size={16}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="ค้นหาโครงการ แจ้งซ่อม หรืออุปกรณ์..."/><kbd>Ctrl K</kbd></div>
          <div className="popover-wrap">
            <button className="icon-btn notification-btn" onClick={() => {setShowNotifications(!showNotifications);setShowProfile(false)}}><Bell size={18}/><i>10</i></button>
            {showNotifications && <div className="popover notification-pop"><strong>การแจ้งเตือน</strong><p><b>มีงานแจ้งซ่อมใหม่</b><small>ระบบไฟฟ้าชั้น 2 · 10 นาทีที่แล้ว</small></p><p><b>โครงการใกล้ครบกำหนด</b><small>บ้านพักอาศัย 2 ชั้น · 1 ชั่วโมงที่แล้ว</small></p><p><b>รอตรวจรับงาน 3 รายการ</b><small>วันนี้ · 09:15 น.</small></p></div>}
          </div>
          <div className="popover-wrap">
            <button className="profile-btn" onClick={() => {setShowProfile(!showProfile);setShowNotifications(false)}}><div className="avatar small">ก</div><span>ผู้ดูแลระบบ</span><ChevronDown size={14}/></button>
            {showProfile && <div className="popover profile-pop"><strong>ผู้ดูแลระบบ</strong><small>admin@homecraft.co.th</small><button onClick={() => notify('เปิดหน้าตั้งค่าบัญชี')}>ตั้งค่าบัญชี</button><button onClick={() => notify('ออกจากระบบ (ตัวอย่าง)')}>ออกจากระบบ</button></div>}
          </div>
        </div>
      </header>

      <div className="content">
        <div className="page-heading">
          <div>
            <div className="date-line"><CalendarDays size={15}/> วันพุธที่ 25 พฤศจิกายน พ.ศ. 2569</div>
            <h1>{isDashboard ? <>สวัสดีตอนเช้า, <span>ผู้ดูแลระบบ</span></> : pageTitle}</h1>
            <p className="subheading"><Building2 size={14}/> บริษัท โฮมกราฟท์ บิลเดอร์ จำกัด <span>·</span> ดำเนินงานมา 12 ปี <span>·</span> <Users size={14}/> กำลังก่อสร้าง 11 โครงการ <span>·</span> <CheckCircle2 size={14}/> อยู่ในระยะรับประกัน 5 หลัง</p>
          </div>
          <div className="heading-actions">
            <button className="btn btn-light" onClick={() => window.print()}><Printer size={16}/> พิมพ์สรุป</button>
            <button className="btn btn-light" onClick={() => setActive('แจ้งซ่อม/ปัญหา')}><AlertTriangle size={16}/> แจ้งซ่อม</button>
            <button className="btn btn-primary" onClick={() => setShowCreate(true)}><Plus size={17}/> สร้างโครงการ</button>
          </div>
        </div>

        {isDashboard ? <>
          <section className="kpi-grid">
            <KpiCard icon={<Building2/>} tone="blue" label="โครงการที่กำลังก่อสร้าง" value="11" unit="โครงการ" note="มูลค่ารวม ฿142 ล้าน · วางแผน 3" trend={[18,15,19,17,22,20,25,26,29,31]}/>
            <KpiCard icon={<Wallet/>} tone="amber" label="มูลค่าสัญญาปี 2569" value="฿82.5" unit="ล้านบาท" note="12 สัญญา · ปี 2568 ฿95.8 ล้าน" badge="↓ -14%" trend={[15,18,16,22,17,28,18,20,19,24]}/>
            <div className="kpi-card">
              <div className="kpi-top"><div className="kpi-icon green"><ArrowUpRight size={18}/></div><span className="kpi-label">ความคืบหน้าเฉลี่ย vs แผน</span></div>
              <div className="kpi-value">52% <small>แผน 54%</small></div><div className="kpi-note">ล่าช้ากว่าแผน 1 โครงการ</div>
              <div className="progress-track"><div className="progress-fill" style={{width:'52%'}}/><span className="plan-marker" style={{left:'54%'}}/></div>
              <div className="legend-inline"><span><i className="dot blue-dot"/> จริง</span><span><i className="dot gray-dot"/> แผน</span><span><i className="dot dark-dot"/> เป้าหมายวันนี้</span></div>
            </div>
            <KpiCard icon={<House/>} tone="mint" label="บ้านที่ส่งมอบแล้ว" value="26" unit="หลัง" note="ปี 2569 2 หลัง · ถัดไป 13 พ.ย." trend={[25,34,30,26,32,27,29,26,24,26]}/>
            <div className="kpi-card repair-kpi">
              <div className="kpi-top"><div className="kpi-icon rose"><Wrench size={18}/></div><span className="kpi-label">แจ้งซ่อมที่เปิดอยู่</span></div>
              <div className="kpi-value">20 <small>เรื่อง</small></div><div className="kpi-note">ด่วน 5 · เกิน SLA 5 · อายุเฉลี่ย 4.7 วัน</div>
              <div className="sla-row"><span>อยู่ในกำหนด SLA</span><b>75%</b></div><div className="sla-track"><span/></div>
            </div>
            <KpiCard icon={<ClipboardCheck/>} tone="cyan" label="การตรวจ 30 วันล่าสุด" value="44" unit="ครั้ง" note="อัตราผ่าน 68% · คะแนนเฉลี่ย 91 · นัดถัดไป 12" trend={[10,12,9,13,11,15,13,18,26,15]}/>
            <div className="kpi-card">
              <div className="kpi-top"><div className="kpi-icon gold"><span className="star">★</span></div><span className="kpi-label">ความพึงพอใจลูกค้า</span></div>
              <div className="kpi-value">4.54<small> / 5</small></div><div className="stars">★★★★★ <span>จาก 26 ครอบครัว</span></div><MiniLine values={[4.2,4.5,4.3,4.4,4.55,4.48,4.6,4.54]}/>
            </div>
            <div className="kpi-card">
              <div className="kpi-top"><div className="kpi-icon purple"><Package size={18}/></div><span className="kpi-label">มูลค่างานในมือ (Backlog)</span></div>
              <div className="kpi-value">฿87.7 <small>ล้านบาท</small></div><div className="kpi-note">งานที่ยังไม่ส่งมอบ 14 โครงการ (ส่วนที่เหลือตามความคืบหน้า)</div>
            </div>
          </section>

          <section className="analytics-grid">
            <div className="panel trend-panel">
              <div className="panel-header"><div className="panel-title"><div className="panel-icon"><BarChart3 size={17}/></div><div><h2>มูลค่าสัญญา & การส่งมอบบ้าน</h2><p>24 เดือนล่าสุด · ล้านบาท (นับตามเดือนเริ่มก่อสร้าง)</p></div></div><div className="panel-controls"><select value={range} onChange={e=>setRange(e.target.value)}><option>12 เดือน</option><option>24 เดือน</option><option>ปีนี้</option></select><button className="dots-btn" onClick={() => notify('ตัวเลือกกราฟ') }><MoreHorizontal size={18}/></button></div></div>
              <div className="chart-summary"><div><small>มูลค่าสัญญา 24 เดือน</small><strong>฿171.4 ล้าน</strong></div><div><small>จำนวนสัญญา</small><strong>15 โครงการ</strong></div><div><small>มูลค่าเฉลี่ย/สัญญา</small><strong>฿11.43 ล้าน</strong></div><div><small>ส่งมอบ 24 เดือน</small><strong>4 หลัง</strong></div></div>
              <div className="chart-area"><ResponsiveContainer width="100%" height="100%"><BarChart data={range === '12 เดือน' ? trend : [...trend,...trend]} margin={{top:8,right:8,left:0,bottom:0}}><CartesianGrid strokeDasharray="3 4" vertical={false} stroke="#edf0f4"/><XAxis dataKey="month" tick={{fontSize:10,fill:'#929ba8'}} axisLine={false} tickLine={false}/><YAxis tick={{fontSize:10,fill:'#929ba8'}} axisLine={false} tickLine={false} tickFormatter={v=>`฿${v}m`}/><Tooltip formatter={(v,n)=>[`฿${v} ล้าน`,n==='contract'?'มูลค่าสัญญา':'ส่งมอบ']}/><Bar dataKey="contract" fill="#2787b0" radius={[4,4,0,0]} barSize={18}/><Area dataKey="delivered" stroke="#c49b5a" fill="none"/></BarChart></ResponsiveContainer></div>
              <div className="chart-legend"><span><i className="legend-square"/> มูลค่าสัญญา</span><span><i className="legend-line"/> ค่าเฉลี่ย 12 เดือน</span><span><i className="legend-green"/> ส่งมอบ</span></div>
            </div>
            <div className="panel status-panel">
              <div className="panel-header"><div className="panel-title"><div className="panel-icon"><Clock3 size={17}/></div><div><h2>สถานะโครงการ</h2><p>ทั้งหมด 40 โครงการ ตั้งแต่ปี 2557</p></div></div><button className="text-link" onClick={() => setActive('โครงการทั้งหมด')}>ทั้งหมด <ArrowUpRight size={14}/></button></div>
              <div className="donut-wrap"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={statusData} dataKey="value" nameKey="name" innerRadius={66} outerRadius={91} paddingAngle={2} stroke="none"><Cell fill="#e99b18"/><Cell fill="#16b889"/><Cell fill="#8b5cf6"/><Cell fill="#2d91c1"/></Pie><Tooltip/></PieChart></ResponsiveContainer><div className="donut-center"><strong>40</strong><span>โครงการ</span></div></div>
              <div className="status-list">{statusData.map(s=><div key={s.name}><span><i style={{background:s.color}}/>{s.name}</span><b>{s.value}</b><small>{Math.round(s.value/40*100)}%</small></div>)}</div>
            </div>
          </section>

          <section className="bottom-grid">
            <div className="panel projects-panel">
              <div className="panel-header"><div className="panel-title"><div className="panel-icon"><Building2 size={17}/></div><div><h2>โครงการล่าสุด</h2><p>ติดตามสถานะและความคืบหน้าของโครงการ</p></div></div><button className="text-link" onClick={()=>setActive('โครงการทั้งหมด')}>ดูทั้งหมด <ArrowUpRight size={14}/></button></div>
              <ProjectTable rows={filteredProjects.slice(0,4)}/>
            </div>
            <div className="panel repairs-panel">
              <div className="panel-header"><div className="panel-title"><div className="panel-icon"><Wrench size={17}/></div><div><h2>งานแจ้งซ่อมล่าสุด</h2><p>รายการที่ต้องติดตาม</p></div></div><button className="text-link" onClick={()=>setActive('แจ้งซ่อม/ปัญหา')}>ดูทั้งหมด <ArrowUpRight size={14}/></button></div>
              <div className="repair-list">{repairs.map(r=><div className="repair-item" key={r.id}><div className="repair-symbol"><Wrench size={16}/></div><div className="repair-detail"><strong>{r.title}</strong><small>{r.id} · {r.project}</small><span>{r.age}</span></div><em className={r.priority==='เร่งด่วน'?'urgent':'normal'}>{r.priority}</em></div>)}</div>
            </div>
          </section>
        </> : <section className="panel module-panel">
          <div className="module-toolbar"><div><h2>{active}</h2><p>จัดการข้อมูลและติดตามการดำเนินงานในระบบ ERP</p></div><div className="module-actions"><button className="btn btn-light" onClick={()=>notify('เปิดตัวกรองข้อมูล')}><Filter size={15}/> ตัวกรอง</button><button className="btn btn-primary" onClick={()=>setShowCreate(true)}><Plus size={16}/> เพิ่มรายการ</button></div></div>
          {active.includes('โครงการ') ? <ProjectTable rows={filteredProjects}/> : <div className="empty-module"><div className="empty-icon"><ClipboardList size={28}/></div><h3>พื้นที่จัดการ{active}</h3><p>หน้านี้เตรียมโครงสร้างไว้สำหรับพัฒนาฟังก์ชัน {active} เพิ่มเติม</p><button className="btn btn-primary" onClick={()=>notify(`เริ่มเพิ่มข้อมูล${active}`)}><Plus size={16}/> สร้างรายการแรก</button></div>}
        </section>}
        <footer className="footer"><span>© 2026 HomeCraft Builder ERP</span><span>BuildFlow ERP <b>v1.0.0</b></span></footer>
      </div>
    </main>

    {showCreate && <div className="modal-backdrop" onClick={()=>setShowCreate(false)}><div className="modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><div><h2>สร้างโครงการใหม่</h2><p>กรอกข้อมูลเบื้องต้นเพื่อเพิ่มโครงการเข้าสู่ระบบ</p></div><button className="icon-btn" onClick={()=>setShowCreate(false)}><X size={19}/></button></div><form onSubmit={e=>{e.preventDefault();setShowCreate(false);notify('บันทึกโครงการตัวอย่างเรียบร้อย')}}><label>ชื่อโครงการ<input required placeholder="เช่น บ้านพักอาศัย 2 ชั้น"/></label><div className="form-row"><label>ชื่อลูกค้า<input required placeholder="ชื่อ-นามสกุล / บริษัท"/></label><label>มูลค่าสัญญา<input placeholder="เช่น 5,500,000"/></label></div><div className="form-row"><label>วันที่เริ่มโครงการ<input type="date"/></label><label>กำหนดส่งมอบ<input type="date"/></label></div><label>รายละเอียด<textarea rows="3" placeholder="รายละเอียดเพิ่มเติม..."/></label><div className="modal-actions"><button type="button" className="btn btn-light" onClick={()=>setShowCreate(false)}>ยกเลิก</button><button type="submit" className="btn btn-primary"><Plus size={16}/> บันทึกโครงการ</button></div></form></div></div>}
    {toast && <div className="toast"><CheckCircle2 size={17}/>{toast}</div>}
  </div>;
}

function KpiCard({icon,tone,label,value,unit,note,badge,trend}) {
  return <div className="kpi-card"><div className="kpi-top"><div className={`kpi-icon ${tone}`}>{React.cloneElement(icon,{size:18})}</div><span className="kpi-label">{label}</span>{badge&&<em className="kpi-badge">{badge}</em>}</div><div className="kpi-value">{value}<small>{unit}</small></div><div className="kpi-note">{note}</div>{trend&&<div className="sparkline"><ResponsiveContainer width="100%" height="100%"><AreaChart data={trend.map((v,i)=>({i,v}))}><Area type="monotone" dataKey="v" stroke={tone==='amber'?'#c69a5c':'#2787b0'} fill={tone==='mint'?'#bceadd':'#dcecf3'} strokeWidth={1.8}/></AreaChart></ResponsiveContainer></div>}</div>
}
function MiniLine({values}) { return <div className="mini-line"><ResponsiveContainer width="100%" height="100%"><AreaChart data={values.map((v,i)=>({i,v}))}><Area dataKey="v" type="monotone" stroke="#d8a33d" fill="none" strokeWidth={2}/></AreaChart></ResponsiveContainer></div> }
function ProjectTable({rows}) {
  return <div className="table-scroll"><table className="project-table"><thead><tr><th>ชื่อโครงการ</th><th>ลูกค้า</th><th>ความคืบหน้า</th><th>สถานะ</th><th>มูลค่าสัญญา</th><th>กำหนดส่งมอบ</th></tr></thead><tbody>{rows.map(p=><tr key={p.id}><td><strong>{p.name}</strong><small>{p.id}</small></td><td>{p.client}</td><td><div className="table-progress"><span><i style={{width:`${p.progress}%`}}/></span><b>{p.progress}%</b></div></td><td><span className={`status-pill ${p.status==='ส่งมอบแล้ว'?'done':p.status==='วางแผน'?'planned':'working'}`}>{p.status}</span></td><td className="money">{p.value}</td><td>{p.date}</td></tr>)}</tbody></table>{rows.length===0&&<div className="no-results">ไม่พบข้อมูลที่ตรงกับคำค้นหา</div>}</div>
}

createRoot(document.getElementById('root')).render(<App/>);